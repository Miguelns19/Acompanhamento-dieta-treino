from datetime import date
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.core.management.base import BaseCommand

from accounts.models import Aluno
from accounts.permissions import ALUNO_GROUP, PERSONAL_GROUP
from alimentacao.models import Alimento
from treinos.models import Exercicio

User = get_user_model()
SENHA = "troque-esta-senha-123"


class Command(BaseCommand):
    help = "Cria dados FICTÍCIOS para desenvolvimento (nunca use dados reais)."

    def handle(self, *args, **options):
        grupo_personal, _ = Group.objects.get_or_create(name=PERSONAL_GROUP)
        grupo_aluno, _ = Group.objects.get_or_create(name=ALUNO_GROUP)

        personal, criado = User.objects.get_or_create(
            username="personal@exemplo.com",
            defaults={"email": "personal@exemplo.com", "first_name": "Personal", "last_name": "Demo"},
        )
        if criado:
            personal.set_password(SENHA)
            personal.save()
        personal.groups.add(grupo_personal)

        for n in (1, 2):
            email = f"aluno{n}@exemplo.com"
            usuario, criado = User.objects.get_or_create(
                username=email, defaults={"email": email, "first_name": f"Aluno {n}", "last_name": "Demo"}
            )
            if criado:
                usuario.set_password(SENHA)
                usuario.save()
            usuario.groups.add(grupo_aluno)
            Aluno.objects.get_or_create(usuario=usuario, defaults={"personal": personal})

        Exercicio.objects.get_or_create(nome="Agachamento livre", defaults={"grupo_muscular": "Pernas"})
        Exercicio.objects.get_or_create(nome="Supino reto", defaults={"grupo_muscular": "Peito"})

        # Valores ILUSTRATIVOS, não são da TACO/TBCA. Substitua pela importação real.
        for nome, kcal, prot, carb, lip in [
            ("Arroz branco cozido", "130", "2.5", "28.1", "0.2"),
            ("Feijão cozido", "76", "4.8", "13.6", "0.5"),
            ("Peito de frango grelhado", "159", "32.0", "0.0", "2.5"),
        ]:
            Alimento.objects.get_or_create(
                nome=nome,
                fonte="DEMO",
                codigo_fonte=nome[:10],
                defaults={
                    "energia_kcal": Decimal(kcal),
                    "proteina_g": Decimal(prot),
                    "carboidrato_g": Decimal(carb),
                    "lipidios_g": Decimal(lip),
                },
            )

        self.stdout.write(self.style.SUCCESS(
            f"Pronto. Personal: personal@exemplo.com | alunos: aluno1/aluno2@exemplo.com | senha: {SENHA}"
        ))
