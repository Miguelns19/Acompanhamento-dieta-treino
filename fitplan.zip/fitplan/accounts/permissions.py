from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin

PERSONAL_GROUP = "Personal"
ALUNO_GROUP = "Aluno"


def is_personal(user):
    return user.is_authenticated and user.groups.filter(name=PERSONAL_GROUP).exists()


def is_aluno(user):
    return user.is_authenticated and hasattr(user, "aluno")


class PersonalRequiredMixin(LoginRequiredMixin, UserPassesTestMixin):
    """Anônimo vai para o login; usuário sem perfil de personal recebe 403."""

    def test_func(self):
        return is_personal(self.request.user)
