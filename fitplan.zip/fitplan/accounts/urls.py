from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

urlpatterns = [
    path("", views.painel, name="painel"),
    path("entrar/", auth_views.LoginView.as_view(), name="login"),
    path("sair/", auth_views.LogoutView.as_view(), name="logout"),
    path("perfil/", views.PerfilView.as_view(), name="perfil"),
    path("alunos/", views.AlunoListView.as_view(), name="alunos_lista"),
    path("alunos/novo/", views.AlunoCreateView.as_view(), name="alunos_novo"),
    path("alunos/<int:pk>/", views.AlunoDetailView.as_view(), name="alunos_detalhe"),
    path(
        "alunos/<int:pk>/alternar-status/",
        views.AlunoAlternarStatusView.as_view(),
        name="alunos_alternar_status",
    ),
]
