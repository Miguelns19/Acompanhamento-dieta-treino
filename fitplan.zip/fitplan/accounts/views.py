from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.views import View
from django.views.generic import DetailView, FormView, ListView, UpdateView

from .forms import AlunoCreateForm, PerfilForm
from .models import Aluno
from .permissions import PersonalRequiredMixin, is_aluno, is_personal


@login_required
def painel(request):
    if is_personal(request.user):
        alunos = Aluno.objects.filter(personal=request.user).select_related("usuario")
        return render(
            request,
            "painel_personal.html",
            {"alunos": alunos, "total_ativos": alunos.filter(status=Aluno.Status.ATIVO).count()},
        )
    if is_aluno(request.user):
        return render(request, "painel_aluno.html", {"aluno": request.user.aluno})
    return render(request, "sem_perfil.html", status=403)


class AlunoListView(PersonalRequiredMixin, ListView):
    template_name = "alunos/lista.html"
    context_object_name = "alunos"

    def get_queryset(self):
        return Aluno.objects.filter(personal=self.request.user).select_related("usuario")


class AlunoCreateView(PersonalRequiredMixin, FormView):
    template_name = "alunos/form.html"
    form_class = AlunoCreateForm
    success_url = reverse_lazy("alunos_lista")

    def form_valid(self, form):
        aluno = form.save(personal=self.request.user)
        messages.success(self.request, f"Aluno {aluno} cadastrado.")
        return super().form_valid(form)


class AlunoDetailView(PersonalRequiredMixin, DetailView):
    template_name = "alunos/detalhe.html"
    context_object_name = "aluno"

    def get_queryset(self):
        # O personal só enxerga alunos vinculados a ele (outros retornam 404).
        return Aluno.objects.filter(personal=self.request.user).select_related("usuario")


class AlunoAlternarStatusView(PersonalRequiredMixin, View):
    http_method_names = ["post"]

    def post(self, request, pk):
        aluno = get_object_or_404(Aluno, pk=pk, personal=request.user)
        if aluno.ativo:
            aluno.status = Aluno.Status.INATIVO
            aluno.usuario.is_active = False
        else:
            aluno.status = Aluno.Status.ATIVO
            aluno.usuario.is_active = True
        aluno.usuario.save(update_fields=["is_active"])
        aluno.save(update_fields=["status"])
        messages.success(request, f"Aluno {aluno} agora está {aluno.get_status_display().lower()}.")
        return redirect("alunos_lista")


class PerfilView(LoginRequiredMixin, UpdateView):
    template_name = "perfil.html"
    form_class = PerfilForm
    success_url = reverse_lazy("painel")

    def get_object(self, queryset=None):
        return self.request.user

    def form_valid(self, form):
        messages.success(self.request, "Dados atualizados.")
        return super().form_valid(form)
