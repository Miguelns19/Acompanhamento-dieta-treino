from django.apps import AppConfig
from django.db.models.signals import post_migrate


def criar_grupos(sender, **kwargs):
    from django.contrib.auth.models import Group

    from .permissions import ALUNO_GROUP, PERSONAL_GROUP

    for nome in (PERSONAL_GROUP, ALUNO_GROUP):
        Group.objects.get_or_create(name=nome)


class AccountsConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "accounts"

    def ready(self):
        post_migrate.connect(criar_grupos, sender=self)
