from decimal import Decimal

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.test import TestCase
from django.urls import reverse

from alimentacao.models import Alimento, ItemConsumido, RefeicaoConsumida, calcular_nutriente
from .models import Aluno
from .permissions import PERSONAL_GROUP

User = get_user_model()
SENHA = "senha-forte-12345"


def criar_personal(email):
    u = User.objects.create_user(username=email, email=email, password=SENHA)
    u.groups.add(Group.objects.get(name=PERSONAL_GROUP))
    return u


class ControleDeAcessoTests(TestCase):
    def setUp(self):
        self.personal = criar_personal("p1@exemplo.com")
        self.client.login(username="p1@exemplo.com", password=SENHA)
        for n in (1, 2):
            resp = self.client.post(
                reverse("alunos_novo"),
                {"nome": f"Aluno{n}", "sobrenome": "Teste", "email": f"a{n}@exemplo.com", "senha_temporaria": SENHA},
            )
            self.assertRedirects(resp, reverse("alunos_lista"))
        self.a1 = Aluno.objects.get(usuario__username="a1@exemplo.com")
        self.a2 = Aluno.objects.get(usuario__username="a2@exemplo.com")
        self.client.logout()

    def test_personal_cadastra_dois_alunos(self):
        self.assertEqual(Aluno.objects.filter(personal=self.personal).count(), 2)

    def test_aluno_nao_ve_dados_do_outro(self):
        self.client.login(username="a1@exemplo.com", password=SENHA)
        self.assertEqual(self.client.get(reverse("painel")).status_code, 200)
        # Aluno não acessa telas do personal
        self.assertEqual(self.client.get(reverse("alunos_lista")).status_code, 403)
        self.assertEqual(self.client.get(reverse("alunos_detalhe", args=[self.a2.pk])).status_code, 403)

    def test_personal_nao_ve_aluno_de_outro_personal(self):
        criar_personal("p2@exemplo.com")
        self.client.login(username="p2@exemplo.com", password=SENHA)
        self.assertEqual(self.client.get(reverse("alunos_detalhe", args=[self.a1.pk])).status_code, 404)
        self.assertEqual(self.client.post(reverse("alunos_alternar_status", args=[self.a1.pk])).status_code, 404)

    def test_anonimo_vai_para_login(self):
        resp = self.client.get(reverse("painel"))
        self.assertEqual(resp.status_code, 302)
        self.assertIn(reverse("login"), resp["Location"])

    def test_desativar_aluno_bloqueia_login(self):
        self.client.login(username="p1@exemplo.com", password=SENHA)
        self.client.post(reverse("alunos_alternar_status", args=[self.a1.pk]))
        self.client.logout()
        self.assertFalse(self.client.login(username="a1@exemplo.com", password=SENHA))


class CalculoNutricionalTests(TestCase):
    def test_formula(self):
        self.assertEqual(calcular_nutriente(150, Decimal("130")), Decimal("195.00"))

    def test_historico_nao_muda_ao_editar_alimento(self):
        personal = criar_personal("p@exemplo.com")
        usuario = User.objects.create_user(username="a@exemplo.com", password=SENHA)
        aluno = Aluno.objects.create(usuario=usuario, personal=personal)
        arroz = Alimento.objects.create(
            nome="Arroz", fonte="DEMO", energia_kcal=130, proteina_g=2.5, carboidrato_g=28, lipidios_g=0.2
        )
        refeicao = RefeicaoConsumida.objects.create(aluno=aluno, data="2026-01-01", tipo="almoco")
        item = ItemConsumido.objects.create(refeicao=refeicao, alimento=arroz, quantidade_g=100)
        arroz.energia_kcal = 999
        arroz.save()
        item.refresh_from_db()
        self.assertEqual(item.energia_kcal, Decimal("130.00"))
