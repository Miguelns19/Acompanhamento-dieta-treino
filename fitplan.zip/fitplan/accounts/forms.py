from django import forms
from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group
from django.contrib.auth.password_validation import validate_password
from django.db import transaction

from .models import Aluno
from .permissions import ALUNO_GROUP

User = get_user_model()


class AlunoCreateForm(forms.Form):
    nome = forms.CharField(max_length=150)
    sobrenome = forms.CharField(max_length=150, required=False)
    email = forms.EmailField()
    senha_temporaria = forms.CharField(widget=forms.PasswordInput, label="Senha temporária")

    def clean_email(self):
        email = self.cleaned_data["email"].strip().lower()
        if User.objects.filter(username__iexact=email).exists():
            raise forms.ValidationError("Já existe um usuário com este e-mail.")
        return email

    def clean_senha_temporaria(self):
        senha = self.cleaned_data["senha_temporaria"]
        validate_password(senha)
        return senha

    @transaction.atomic
    def save(self, personal):
        dados = self.cleaned_data
        usuario = User.objects.create_user(
            username=dados["email"],
            email=dados["email"],
            password=dados["senha_temporaria"],
            first_name=dados["nome"],
            last_name=dados["sobrenome"],
        )
        grupo, _ = Group.objects.get_or_create(name=ALUNO_GROUP)
        usuario.groups.add(grupo)
        return Aluno.objects.create(usuario=usuario, personal=personal)


class PerfilForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ["first_name", "last_name"]
        labels = {"first_name": "Nome", "last_name": "Sobrenome"}
