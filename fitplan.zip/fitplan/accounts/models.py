from django.conf import settings
from django.db import models


class Aluno(models.Model):
    """Perfil de aluno. O login e a senha ficam no User do Django."""

    class Status(models.TextChoices):
        ATIVO = "ativo", "Ativo"
        INATIVO = "inativo", "Inativo"

    usuario = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="aluno"
    )
    personal = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="alunos"
    )
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.ATIVO)
    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["usuario__first_name", "usuario__last_name"]

    def __str__(self):
        return self.usuario.get_full_name() or self.usuario.username

    @property
    def ativo(self):
        return self.status == self.Status.ATIVO
