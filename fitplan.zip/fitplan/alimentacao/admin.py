from django.contrib import admin

from .models import (
    Alimento,
    ItemConsumido,
    ItemPlanoAlimentar,
    MetaNutricional,
    PlanoAlimentar,
    RefeicaoConsumida,
)


class ItemPlanoInline(admin.TabularInline):
    model = ItemPlanoAlimentar
    extra = 1


class ItemConsumidoInline(admin.TabularInline):
    model = ItemConsumido
    extra = 1
    readonly_fields = ("energia_kcal", "proteina_g", "carboidrato_g", "lipidios_g")


@admin.register(Alimento)
class AlimentoAdmin(admin.ModelAdmin):
    list_display = ("nome", "preparo", "fonte", "energia_kcal")
    search_fields = ("nome",)


@admin.register(PlanoAlimentar)
class PlanoAlimentarAdmin(admin.ModelAdmin):
    inlines = [ItemPlanoInline]


@admin.register(RefeicaoConsumida)
class RefeicaoConsumidaAdmin(admin.ModelAdmin):
    list_display = ("aluno", "data", "tipo")
    inlines = [ItemConsumidoInline]


admin.site.register(MetaNutricional)
