from decimal import Decimal

from django.db import models

CASAS = Decimal("0.01")


def calcular_nutriente(quantidade_g, por_100g):
    """nutriente consumido = quantidade em gramas x nutriente por 100 g / 100"""
    return (Decimal(quantidade_g) * Decimal(por_100g) / Decimal(100)).quantize(CASAS)


class TipoRefeicao(models.TextChoices):
    CAFE = "cafe", "Café da manhã"
    LANCHE_MANHA = "lanche_manha", "Lanche da manhã"
    ALMOCO = "almoco", "Almoço"
    LANCHE_TARDE = "lanche_tarde", "Lanche da tarde"
    JANTAR = "jantar", "Jantar"
    CEIA = "ceia", "Ceia"


class Alimento(models.Model):
    nome = models.CharField(max_length=200)
    preparo = models.CharField(max_length=100, blank=True)
    fonte = models.CharField(max_length=50, help_text="Ex.: TBCA, TACO")
    codigo_fonte = models.CharField(max_length=50, blank=True)
    # Valores por 100 g
    energia_kcal = models.DecimalField(max_digits=7, decimal_places=2)
    proteina_g = models.DecimalField(max_digits=6, decimal_places=2)
    carboidrato_g = models.DecimalField(max_digits=6, decimal_places=2)
    lipidios_g = models.DecimalField(max_digits=6, decimal_places=2)

    class Meta:
        ordering = ["nome"]
        constraints = [
            models.UniqueConstraint(
                fields=["fonte", "codigo_fonte"],
                condition=~models.Q(codigo_fonte=""),
                name="alimento_unico_por_fonte",
            )
        ]

    def __str__(self):
        return f"{self.nome} ({self.preparo})" if self.preparo else self.nome


class PlanoAlimentar(models.Model):
    class Origem(models.TextChoices):
        NUTRICIONISTA = "nutricionista", "Nutricionista habilitado"
        PERSONAL_HABILITADO = "personal_habilitado", "Personal com habilitação em nutrição"

    aluno = models.ForeignKey("accounts.Aluno", on_delete=models.CASCADE, related_name="planos_alimentares")
    inicio = models.DateField()
    fim = models.DateField(null=True, blank=True)
    origem = models.CharField(max_length=30, choices=Origem.choices)
    profissional = models.CharField(max_length=150, blank=True, help_text="Nome de quem prescreveu o plano")

    def __str__(self):
        return f"Plano de {self.aluno} desde {self.inicio}"


class ItemPlanoAlimentar(models.Model):
    plano = models.ForeignKey(PlanoAlimentar, on_delete=models.CASCADE, related_name="itens")
    refeicao = models.CharField(max_length=20, choices=TipoRefeicao.choices)
    alimento = models.ForeignKey(Alimento, on_delete=models.PROTECT)
    quantidade_g = models.DecimalField(max_digits=7, decimal_places=2)


class RefeicaoConsumida(models.Model):
    aluno = models.ForeignKey("accounts.Aluno", on_delete=models.CASCADE, related_name="refeicoes")
    data = models.DateField()
    tipo = models.CharField(max_length=20, choices=TipoRefeicao.choices)

    class Meta:
        ordering = ["-data"]

    def __str__(self):
        return f"{self.get_tipo_display()} de {self.aluno} em {self.data}"


class ItemConsumido(models.Model):
    """Guarda os nutrientes calculados na criação: editar o Alimento depois
    ou mudar o plano alimentar não altera o histórico."""

    refeicao = models.ForeignKey(RefeicaoConsumida, on_delete=models.CASCADE, related_name="itens")
    alimento = models.ForeignKey(Alimento, on_delete=models.PROTECT)
    item_plano = models.ForeignKey(ItemPlanoAlimentar, null=True, blank=True, on_delete=models.SET_NULL)
    quantidade_g = models.DecimalField(max_digits=7, decimal_places=2)
    energia_kcal = models.DecimalField(max_digits=8, decimal_places=2, editable=False)
    proteina_g = models.DecimalField(max_digits=7, decimal_places=2, editable=False)
    carboidrato_g = models.DecimalField(max_digits=7, decimal_places=2, editable=False)
    lipidios_g = models.DecimalField(max_digits=7, decimal_places=2, editable=False)

    def save(self, *args, **kwargs):
        if self._state.adding:
            a = self.alimento
            self.energia_kcal = calcular_nutriente(self.quantidade_g, a.energia_kcal)
            self.proteina_g = calcular_nutriente(self.quantidade_g, a.proteina_g)
            self.carboidrato_g = calcular_nutriente(self.quantidade_g, a.carboidrato_g)
            self.lipidios_g = calcular_nutriente(self.quantidade_g, a.lipidios_g)
        super().save(*args, **kwargs)


class MetaNutricional(models.Model):
    aluno = models.ForeignKey("accounts.Aluno", on_delete=models.CASCADE, related_name="metas")
    inicio = models.DateField()
    fim = models.DateField(null=True, blank=True)
    calorias_kcal = models.PositiveIntegerField()
    proteina_g = models.PositiveIntegerField()
    carboidrato_g = models.PositiveIntegerField()
    lipidios_g = models.PositiveIntegerField()

    class Meta:
        ordering = ["-inicio"]
