from django.contrib import admin

from .models import Exercicio, ItemTreino, PlanoTreino, RegistroExercicio


class ItemTreinoInline(admin.TabularInline):
    model = ItemTreino
    extra = 1


@admin.register(PlanoTreino)
class PlanoTreinoAdmin(admin.ModelAdmin):
    list_display = ("nome", "aluno", "inicio", "fim")
    inlines = [ItemTreinoInline]


admin.site.register(Exercicio)
admin.site.register(RegistroExercicio)
