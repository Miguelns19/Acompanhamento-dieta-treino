from django.conf import settings
from django.db import models


class Exercicio(models.Model):
    nome = models.CharField(max_length=120)
    descricao = models.TextField(blank=True)
    grupo_muscular = models.CharField(max_length=60, blank=True)
    criado_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+"
    )

    class Meta:
        ordering = ["nome"]

    def __str__(self):
        return self.nome


class PlanoTreino(models.Model):
    aluno = models.ForeignKey("accounts.Aluno", on_delete=models.CASCADE, related_name="planos_treino")
    nome = models.CharField(max_length=120)
    inicio = models.DateField()
    fim = models.DateField(null=True, blank=True)
    criado_por = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, on_delete=models.SET_NULL, related_name="+"
    )

    class Meta:
        ordering = ["-inicio"]

    def __str__(self):
        return f"{self.nome} - {self.aluno}"


class ItemTreino(models.Model):
    plano = models.ForeignKey(PlanoTreino, on_delete=models.CASCADE, related_name="itens")
    exercicio = models.ForeignKey(Exercicio, on_delete=models.PROTECT)
    ordem = models.PositiveSmallIntegerField(default=1)
    series = models.PositiveSmallIntegerField()
    repeticoes = models.PositiveSmallIntegerField()
    descanso_segundos = models.PositiveSmallIntegerField(null=True, blank=True)

    class Meta:
        ordering = ["plano", "ordem"]

    def __str__(self):
        return f"{self.ordem}. {self.exercicio} ({self.series}x{self.repeticoes})"


class RegistroExercicio(models.Model):
    """Uma execução por exercício. O detalhe por série pode vir depois."""

    aluno = models.ForeignKey("accounts.Aluno", on_delete=models.CASCADE, related_name="registros_exercicio")
    item = models.ForeignKey(ItemTreino, on_delete=models.PROTECT, related_name="registros")
    data = models.DateField()
    carga_kg = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    series_realizadas = models.PositiveSmallIntegerField()
    repeticoes_realizadas = models.PositiveSmallIntegerField()
    observacoes = models.TextField(blank=True)

    class Meta:
        ordering = ["-data"]

    def __str__(self):
        return f"{self.aluno} - {self.item.exercicio} em {self.data}"
