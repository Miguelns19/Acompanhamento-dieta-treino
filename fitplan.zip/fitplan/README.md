# FitPlan: sistema de treinos e alimentação

Site responsivo em Django + Bootstrap, conforme o documento de planejamento.
Perfis: **Personal** (cadastra alunos, prescreve treinos, acompanha registros) e **Aluno** (consulta e registra).

## Como rodar (primeira vez)

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python manage.py makemigrations accounts treinos alimentacao
python manage.py migrate
python manage.py seed_demo       # dados FICTÍCIOS
python manage.py createsuperuser # para usar /admin/
python manage.py runserver
```

Acesse http://127.0.0.1:8000/ e entre com `personal@exemplo.com` (senha impressa pelo `seed_demo`).

Testes: `python manage.py test`

> As migrações (`*/migrations/0001_initial.py`) devem ser geradas com `makemigrations` e **commitadas** no Git, para todo o grupo usar o mesmo banco.

## Estrutura

| App | Conteúdo |
| --- | --- |
| `accounts` | Login, grupos Personal/Aluno, cadastro e desativação de alunos, painéis, controle de acesso |
| `treinos` | Exercício, Plano de treino, Item do treino, Registro de exercício |
| `alimentacao` | Alimento (por 100 g), Plano alimentar, Refeição/Item consumido (nutrientes gravados), Meta nutricional |

## Regras importantes

- Senhas e permissões usam o sistema do Django (grupos `Personal` e `Aluno`).
- Cada aluno só acessa seus dados; o personal só acessa alunos vinculados a ele.
- Item consumido grava os nutrientes calculados (`g × nutriente/100 g ÷ 100`), então editar o alimento não altera o histórico.
- Plano alimentar: origem registrada (nutricionista habilitado ou personal com habilitação).
- Use apenas dados fictícios; não versione `.env`, senhas ou dados reais.
- Os alimentos do `seed_demo` são valores ilustrativos, não da TACO/TBCA.

## PostgreSQL (publicação)

Instale `psycopg[binary]` e defina `POSTGRES_DB`, `POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_HOST`, além de `DJANGO_SECRET_KEY`, `DJANGO_DEBUG=0` e `DJANGO_ALLOWED_HOSTS`.
