# Tarefas por entrega (para virar issues no GitHub)

## Entrega 1: Base funcionando (esqueleto pronto neste repositório)
- [x] Projeto Django, apps e configurações
- [x] Login/logout, grupos Personal e Aluno
- [x] Cadastro e desativação de alunos pelo personal
- [x] Controle de acesso e testes (dois alunos não veem dados um do outro)
- [ ] Rodar `makemigrations`/`migrate` e commitar as migrações
- [ ] Revisar telas no celular

## Entrega 2: Treinos completos
- [ ] CRUD de exercícios (personal)
- [ ] Montar plano de treino com itens (personal)
- [ ] Aluno consulta o treino e registra execução (carga, séries, repetições)
- [ ] Personal visualiza os registros dos alunos

## Entrega 3: Alimentação livre
- [ ] Importar base inicial pequena (TBCA/TACO, após confirmar condições de uso)
- [ ] Busca de alimentos, lançamento em gramas, totais diários

## Entrega 4: Planos e metas
- [ ] Plano alimentar (origem: nutricionista habilitado) e confirmação com ajustes
- [ ] Meta nutricional e comparação consumo × meta

## Entrega 5: Painel e publicação
- [ ] Histórico por período e adesão dos alunos
- [ ] Testes dos fluxos principais
- [ ] Publicação com PostgreSQL para grupo pequeno
- [ ] Definir consentimento, acesso e exclusão de dados

## Divisão sugerida (cada pessoa faz telas e testes da própria frente + revisão cruzada)
1. Autenticação e permissões (`accounts`)
2. Treinos (`treinos`)
3. Alimentação (`alimentacao`: catálogo, busca, lançamento)
4. Planos e metas
5. Painel e publicação
